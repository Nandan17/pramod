package com.example.student;
public class Student {
    private final int id;
    private final int collegeId;
    private final String name;

    public Student(final int id, final int collegeId, final String name) {
        this.id = id;
        this.collegeId = collegeId;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public int getCollegeId() {
        return collegeId;
    }

    public String getName() {
        return name;
    }
}
