package com.example.college;
public class College {
    private final int id;
    private final String name;
    private final String area;

    public College(final int id,  final String name, final String area) {
        this.id = id;
        this.name = name;
        this.area=area;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    
    public String getArea(){
    	return area;
    }
}
